<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ServiceFilter extends Component
{
    public $showModal =false;

    public $programs = true;
    public $setup= true;
    public $target= true;
    public $member= true;
    public $identifier= true;
    public $channel= true;
    public $customers= true;


    public $first= true;
    public $second= true;
    public $third= true;


//    public $brand1 = true;
//    public $brand2 = true;
//    public $brand3 = true;
//    public $brand4 = true;
//    public $brand5 = true;
//    public $brand6 = true;
//    public $brand7 = true;
//    public $brand8 = true;

    public function control() {
        $this->showModal = !$this->showModal;
    }

    public function reser_filters() {
        $this->programs = true;
        $this->setup= true;
        $this->target= true;
        $this->member= true;
        $this->identifier= true;
        $this->channel= true;
        $this->customers= true;
    }

    public function render()
    {
        return view('livewire.service-filter');
    }
}
